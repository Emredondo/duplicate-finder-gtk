# Registro de cambios

## 0.1.1 — 2026-11-12

- Los selectores principal y prioritario abren directamente el explorador de carpetas de GTK.

## 0.1.0 — 2026-11-12

- Motor de detección exacta por tamaño, hash parcial, hash completo y bytes.
- GTK 3: carpeta inicial, opciones, exclusiones, progreso y cancelación.
- Resultados en árbol y tabla ordenable con selección compartida.
- Conservación por antigüedad, fecha reciente o carpeta prioritaria.
- Apertura por GIO, selector de aplicación, mostrar en carpeta, portapapeles y propiedades.
- Papelera exclusivamente, con confirmación, comprobaciones y conservación de copia.
- Manejo de enlaces, permisos, desapariciones y cambios concurrentes.
- Preferencias XDG, restauración de valores predeterminados e incidencias.
- Icono SVG propio, entrada de escritorio, manual y licencia GPL-3.0-or-later.
- Constructor DEB sin privilegios y pruebas automatizadas con CI para Debian 13.
