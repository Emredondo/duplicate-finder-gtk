#!/usr/bin/python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Install/remove in a writable namespace overlay; the host stays read-only.

Uses the existing Debian dependency set, not a freshly bootstrapped distribution.
Requires bubblewrap with user namespaces. Run GUI smoke separately with Xvfb.
"""
from pathlib import Path
import os
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent.parent
PACKAGE = ROOT / "dist/duplicate-finder-gtk_0.1.3_all.deb"


def shadow(source, target, writable_paths):
    """Link existing files to a read-only /mnt, materialize installation parents."""
    target.mkdir(parents=True, exist_ok=True)
    for entry in source.iterdir():
        relative = entry.relative_to("/")
        if str(entry) in writable_paths:
            shadow(entry, target / entry.name, writable_paths)
        else:
            (target / entry.name).symlink_to(Path("/mnt") / relative)


def main():
    if not PACKAGE.is_file():
        raise SystemExit("Build the DEB first")
    with tempfile.TemporaryDirectory(prefix="duplicate-finder-install-") as directory:
        stage = Path(directory)
        # Only parents of new package files need to be writable.
        split = {"/usr/share/applications", "/usr/share/doc", "/usr/share/doc/duplicate-finder-gtk",
                 "/usr/share/duplicate-finder-gtk", "/usr/share/duplicate-finder-gtk/duplicate_finder",
                 "/usr/share/man", "/usr/share/man/man1",
                 "/usr/share/icons", "/usr/share/icons/hicolor", "/usr/share/icons/hicolor/scalable",
                 "/usr/share/icons/hicolor/scalable/apps"}
        shadow(Path("/usr/bin"), stage / "usr/bin", set())
        shadow(Path("/usr/share"), stage / "usr/share", split)
        for relative in ("var/lib/dpkg/info", "var/lib/dpkg/updates", "var/lib/dpkg/triggers",
                         "var/lib/apt/lists/partial", "var/cache/apt/archives/partial", "var/cache/man", "var/log",
                         "etc/apt/apt.conf.d", "etc/apt/sources.list.d", "etc/apt/preferences.d"):
            (stage / relative).mkdir(parents=True, exist_ok=True)
        for entry in Path("/etc").iterdir():
            if entry.name != "apt":
                (stage / "etc" / entry.name).symlink_to(Path("/mnt/etc") / entry.name)
        shutil.copyfile("/var/lib/dpkg/status", stage / "var/lib/dpkg/status")
        shutil.copyfile("/var/lib/dpkg/arch", stage / "var/lib/dpkg/arch")
        for path in Path("/var/lib/dpkg/triggers").iterdir():
            if path.is_file() and path.name != "Lock":
                shutil.copyfile(path, stage / "var/lib/dpkg/triggers" / path.name)
        # Use existing read-only info to avoid false missing-file-list warnings.
        # Installation/removal only adds/deletes our new package's entries.
        for path in Path("/var/lib/dpkg/info").iterdir():
            (stage / "var/lib/dpkg/info" / path.name).symlink_to(Path("/mnt") / path.relative_to("/"))
        (stage / "etc/apt/apt.conf.d/00test").write_text('APT::Sandbox::User "root";\nAcquire::Languages "none";\nDir::Log::Terminal "";\n')
        args = ["bwrap", "--unshare-user", "--uid", "0", "--gid", "0", "--die-with-parent",
                "--ro-bind", "/", "/", "--ro-bind", "/", "/mnt", "--dev", "/dev", "--proc", "/proc",
                "--tmpfs", "/tmp", "--tmpfs", "/run", "--ro-bind", str(ROOT), "/tmp/project"]
        for path in ("usr/bin", "usr/share", "var/lib/dpkg", "var/lib/apt", "var/cache/apt", "var/cache/man", "var/log", "etc"):
            args.extend(["--bind", str(stage / path), "/" + path])
        if Path("/tmp/.X11-unix").is_dir():
            args.extend(["--ro-bind", "/tmp/.X11-unix", "/tmp/.X11-unix"])
        authority = os.environ.get("XAUTHORITY")
        if authority and Path(authority).is_file() and authority.startswith("/tmp/"):
            args.extend(["--ro-bind", authority, authority])
        args.extend(["--setenv", "XDG_CONFIG_HOME", "/tmp/df-config", "--setenv", "XDG_DATA_HOME", "/tmp/df-data",
                     "--setenv", "XDG_CACHE_HOME", "/tmp/df-cache", "--setenv", "GTK_THEME", "Adwaita",
                     "--chdir", "/tmp", "/usr/bin/python3", "-u", "/tmp/project/tools/verify_package_inner.py"])
        subprocess.run(args, check=True)


if __name__ == "__main__":
    main()
