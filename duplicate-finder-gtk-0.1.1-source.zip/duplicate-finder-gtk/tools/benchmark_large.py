#!/usr/bin/python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Optional real >4 GiB streaming check using sparse, temporary fixtures."""
from pathlib import Path
import resource
import sys
import tempfile
import time
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from duplicate_finder.engine import Scanner


def main():
    size = 5 * 1024 ** 3 + 17
    started = time.monotonic()
    with tempfile.TemporaryDirectory(prefix="duplicate-finder-large-") as directory:
        root = Path(directory)
        for name in ("five-gib-video.mp4", "same-bytes-photo.bin"):
            with (root / name).open("wb") as stream:
                stream.truncate(size)
                stream.seek(size - 1)
                stream.write(b"x")
        result = Scanner().scan(root)
        assert len(result.groups) == 1 and len(result.groups[0].files) == 2
        assert result.potential_bytes == size
        assert not result.errors
        print(f"PASS full SHA-256 and byte comparison of two {size:,}-byte files")
        print(f"Elapsed seconds: {time.monotonic() - started:.3f}")
        print(f"Peak RSS KiB (Linux): {resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}")
        print("Fixtures are sparse; this measures correctness, streaming memory and CPU, not physical disk throughput.")


if __name__ == "__main__":
    main()
