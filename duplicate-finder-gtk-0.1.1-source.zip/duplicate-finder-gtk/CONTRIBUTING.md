# Contribuir

El destino inicial es Debian 13 con Python 3, GTK 3 y PyGObject. Mantenga la detección exacta y el uso exclusivo de la papelera. No incorpore telemetría ni descargue dependencias desde el instalador.

Ejecute `make test check` y `make gui-test` con pantalla gráfica antes de proponer cambios. Los cambios en operaciones de archivos deben cubrir errores, cambios concurrentes, enlaces y la conservación de una copia. La interfaz sólo puede modificarse desde el hilo principal GTK.

Construya con `make deb`. No incorpore preferencias personales, rutas privadas, tokens ni el directorio `dist` al repositorio. Use la licencia GPL-3.0-or-later en contribuciones.

El repositorio público se llamará `duplicate-finder-gtk`. Su propietario se define al publicar; no se presupone ninguna cuenta. El flujo en `.github/workflows/tests.yml` ejecuta las comprobaciones en Debian Trixie.
