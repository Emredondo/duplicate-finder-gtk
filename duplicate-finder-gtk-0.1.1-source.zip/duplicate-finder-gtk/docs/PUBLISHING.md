# Preparación de publicación

Nombre previsto: **duplicate-finder-gtk**. Licencia: **GPL-3.0-or-later**. Versión: **0.1.1**.

La distribución de código incluye módulos completos, pruebas, integración de escritorio, constructor reproducible, documentación y un flujo de GitHub Actions sobre Debian Trixie. No incluye credenciales ni datos de usuario. Los archivos de prueba y capturas son sintéticos.

Antes de publicar:

1. Definir la cuenta u organización propietaria y ajustar el contacto de mantenimiento del paquete. La dirección técnica de esta distribución no presupone una cuenta GitHub del usuario.
2. Confirmar explícitamente que el repositorio puede hacerse público.
3. Crear un repositorio vacío llamado `duplicate-finder-gtk` en esa cuenta, añadir el remoto y enviar la rama principal.
4. Ejecutar el flujo de CI y revisar sus resultados en el entorno Debian limpio de GitHub.
5. Crear la etiqueta `v0.1.1` y una release con el DEB, fuentes y `SHA256SUMS`.

No se realizó ninguna publicación remota desde esta entrega. La verificación local no sustituye la prueba pendiente de instalación en una imagen Debian 13 limpia.
