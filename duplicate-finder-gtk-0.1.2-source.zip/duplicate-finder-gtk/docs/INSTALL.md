# Instalación y reconstrucción

## Usuario final

En Debian 13 Trixie:

```sh
sudo apt install ./duplicate-finder-gtk_0.1.2_all.deb
duplicate-finder-gtk
sudo apt remove duplicate-finder-gtk
```

También puede iniciarse desde el menú **Utilidades → Duplicate Finder GTK**. La categoría exacta depende de la organización del menú del escritorio. El menú XFCE puede necesitar actualizarse después de instalar.

## Dependencias declaradas

- `python3 (>= 3.11)`
- `python3-gi (>= 3.42)`
- `gir1.2-gtk-3.0 (>= 3.24)` — incorpora GTK 3 mediante sus dependencias
- `gir1.2-glib-2.0 (>= 1.70)` — GIO/GLib mediante introspección
- Recomendación: `gvfs` para integración adicional del escritorio

No utiliza pip ni scripts de descarga en instalación. No hay scripts de mantenimiento propios ni modificaciones de configuración global. APT y los paquetes de integración del escritorio atienden las dependencias y sus desencadenadores habituales.

## Construcción

Con Python 3 y dpkg-deb disponibles:

```sh
python3 -m unittest discover -s tests -v
python3 tools/build_deb.py
dpkg-deb --info dist/duplicate-finder-gtk_0.1.2_all.deb
dpkg-deb --contents dist/duplicate-finder-gtk_0.1.2_all.deb
```

El paquete es independiente de arquitectura (`all`), con propietario root en el archivo, construido sin privilegios. Instala el lanzador en `/usr/bin`, los módulos privados en `/usr/share/duplicate-finder-gtk`, el archivo `.desktop` en `/usr/share/applications`, el icono en `/usr/share/icons/hicolor/scalable/apps`, documentación y licencia en `/usr/share/doc/duplicate-finder-gtk` y el manual en `/usr/share/man/man1`.

`SOURCE_DATE_EPOCH` fija marcas de tiempo y gzip. El constructor ignora `__pycache__`, pruebas y archivos ajenos al paquete. No usa compilación dependiente de arquitectura. Una segunda construcción con las mismas entradas debe producir el mismo SHA-256.

## Verificación en una máquina de pruebas

```sh
sudo apt install ./dist/duplicate-finder-gtk_0.1.2_all.deb
duplicate-finder-gtk --version
dpkg --verify duplicate-finder-gtk
desktop-file-validate /usr/share/applications/duplicate-finder-gtk.desktop
```

Abra la aplicación desde el menú XFCE, analice una carpeta de archivos de prueba, compruebe ambas vistas y pruebe la papelera únicamente con esas copias de prueba. Cierre la aplicación antes de desinstalar:

```sh
sudo apt remove duplicate-finder-gtk
```

No se eliminan preferencias XDG ni archivos de la papelera al desinstalar. La instalación en una imagen Debian 13 limpia puede hacerse también mediante el flujo de CI incluido. El informe de verificación distingue lo ejecutado de lo pendiente.
