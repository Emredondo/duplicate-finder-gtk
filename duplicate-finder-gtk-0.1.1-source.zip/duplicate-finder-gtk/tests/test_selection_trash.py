# SPDX-License-Identifier: GPL-3.0-or-later
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock

from duplicate_finder.engine import Scanner
from duplicate_finder.hashing import Cancellation
from duplicate_finder.model import automatic_selection
from duplicate_finder.operations import trash_selected


class SelectionAndTrashTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.paths = []
        for number, name in enumerate(("a", "priority/b", "priority/deep/c"), 1):
            path = self.root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(b"identical data")
            os.utime(path, ns=(number * 1000000000, number * 1000000000))
            self.paths.append(path)
        self.result = Scanner().scan(self.root)
        self.assertEqual(len(self.result.groups), 1)

    def test_oldest(self):
        automatic_selection(self.result, "oldest")
        self.assertEqual(self.result.selected, set(self.paths[1:]))

    def test_newest(self):
        automatic_selection(self.result, "newest")
        self.assertEqual(self.result.selected, set(self.paths[:2]))

    def test_priority_nested_and_oldest_inside(self):
        automatic_selection(self.result, "priority", self.root / "priority")
        self.assertEqual(self.result.selected, {self.paths[0], self.paths[2]})

    def test_priority_missing_falls_back_oldest(self):
        automatic_selection(self.result, "priority", self.root / "other")
        self.assertEqual(self.result.selected, set(self.paths[1:]))

    def test_priority_uses_path_components(self):
        automatic_selection(self.result, "priority", self.root / "prior")
        self.assertEqual(self.result.selected, set(self.paths[1:]))

    def test_priority_requires_folder(self):
        with self.assertRaises(ValueError):
            automatic_selection(self.result, "priority")

    def test_invalid_criterion(self):
        with self.assertRaises(ValueError):
            automatic_selection(self.result, "unknown")

    def test_manual_cannot_select_last_copy(self):
        for path in self.paths[:2]:
            self.assertTrue(self.result.set_selected(path, True))
        self.assertFalse(self.result.set_selected(self.paths[2], True))
        self.assertEqual(len(self.result.selected), 2)
        self.assertTrue(self.result.set_selected(self.paths[0], False))
        self.assertTrue(self.result.set_selected(self.paths[2], True))

    def test_selected_space_updates(self):
        size = self.paths[0].stat().st_size
        self.result.set_selected(self.paths[0], True)
        self.assertEqual(self.result.selected_bytes, size)
        self.result.set_selected(self.paths[0], False)
        self.assertEqual(self.result.selected_bytes, 0)

    def test_tie_deterministic(self):
        for path in self.paths:
            os.utime(path, ns=(1000000000, 1000000000))
        r = Scanner().scan(self.root)
        automatic_selection(r)
        self.assertNotIn(min(self.paths, key=str), r.selected)

    def test_rejects_all_selected_even_if_model_bypassed(self):
        self.result.selected = set(self.paths)
        trash = Mock()
        r = trash_selected(self.result, trash=trash)
        self.assertFalse(r.removed)
        self.assertTrue(r.errors)
        trash.assert_not_called()

    def test_success_and_per_file_callback(self):
        automatic_selection(self.result)
        moved = []
        callbacks = []
        trashdir = self.root / "test-trash"
        trashdir.mkdir()

        def fake_trash(path):
            dest = trashdir / str(len(moved))
            path.rename(dest)
            moved.append(dest)
        r = trash_selected(self.result, trash=fake_trash, on_removed=callbacks.append)
        self.assertEqual(len(r.removed), 2)
        self.assertEqual(callbacks, r.removed)
        self.assertFalse(r.errors)
        self.assertTrue(self.paths[0].exists())
        self.assertEqual(len(self.result.groups[0].files), 3, "worker must not mutate UI model")
        for path in r.removed:
            self.result.remove(path)
        self.assertFalse(self.result.groups)
        self.assertFalse(self.result.selected)

    def test_trash_failure_leaves_file_intact_stops_group(self):
        automatic_selection(self.result)
        trash = Mock(side_effect=OSError("Papelera no disponible"))
        r = trash_selected(self.result, trash=trash)
        self.assertEqual(trash.call_count, 1)
        self.assertTrue(r.errors)
        self.assertFalse(r.removed)
        self.assertTrue(all(p.exists() for p in self.paths))

    def test_modified_keeper_prevents_trash(self):
        automatic_selection(self.result)
        self.paths[0].write_bytes(b"modified keeper")
        trash = Mock()
        r = trash_selected(self.result, trash=trash)
        self.assertTrue(r.errors)
        trash.assert_not_called()

    def test_missing_keeper_prevents_trash(self):
        automatic_selection(self.result)
        self.paths[0].unlink()
        trash = Mock()
        self.assertTrue(trash_selected(self.result, trash=trash).errors)
        trash.assert_not_called()

    def test_changed_target_prevents_entire_group(self):
        automatic_selection(self.result)
        self.paths[2].write_bytes(b"changed target")
        trash = Mock()
        self.assertTrue(trash_selected(self.result, trash=trash).errors)
        trash.assert_not_called()

    def test_mtime_restored_still_detected_via_ctime(self):
        automatic_selection(self.result)
        record = next(f for f in self.result.groups[0].files if f.path == self.paths[1])
        self.paths[1].write_bytes(b"different data")
        os.utime(self.paths[1], ns=(record.mtime_ns, record.mtime_ns))
        trash = Mock()
        self.assertTrue(trash_selected(self.result, trash=trash).errors)
        trash.assert_not_called()

    def test_keeper_changes_between_trash_calls(self):
        automatic_selection(self.result)
        calls = []
        trashdir = self.root / "test-trash"
        trashdir.mkdir()

        def fake_trash(path):
            path.rename(trashdir / "removed")
            calls.append(path)
            self.paths[0].write_bytes(b"keeper changed after first removal")
        r = trash_selected(self.result, trash=fake_trash)
        self.assertEqual(len(r.removed), 1)
        self.assertEqual(len(calls), 1)
        self.assertTrue(r.errors)
        self.assertTrue(self.paths[2].exists())

    def test_cancel_before_trash(self):
        automatic_selection(self.result)
        token = Cancellation()
        token.cancel()
        trash = Mock()
        r = trash_selected(self.result, cancel=token, trash=trash)
        self.assertTrue(r.cancelled)
        trash.assert_not_called()

    def test_cancel_after_first_trash(self):
        automatic_selection(self.result)
        token = Cancellation()
        trashdir = self.root / "test-trash"
        trashdir.mkdir()

        def fake_trash(path):
            path.rename(trashdir / "removed")
            token.cancel()
        r = trash_selected(self.result, cancel=token, trash=fake_trash)
        self.assertEqual(len(r.removed), 1)
        self.assertTrue(r.cancelled)
        self.assertTrue(self.paths[0].exists())

    def test_failed_group_does_not_prevent_independent_group(self):
        x, y = self.root / "x", self.root / "y"
        x.write_bytes(b"other")
        y.write_bytes(b"other")
        r = Scanner().scan(self.root)
        automatic_selection(r)
        calls = []

        def fake_trash(path):
            if path in self.paths:
                raise OSError("failure for first group")
            calls.append(path)
        report = trash_selected(r, trash=fake_trash)
        self.assertEqual(len(calls), 1)
        self.assertEqual(len(report.errors), 1)

    def test_exact_recheck_even_with_forged_fingerprint(self):
        # A fabricated record illustrates why byte verification matters, beyond metadata.
        from duplicate_finder.model import FileRecord
        automatic_selection(self.result)
        self.paths[1].write_bytes(b"mismatched!!!!")
        group = self.result.groups[0]
        group.files = [FileRecord.from_stat(f.path, f.path.stat()) for f in group.files]
        trash = Mock()
        self.assertTrue(trash_selected(self.result, trash=trash).errors)
        trash.assert_not_called()

    def test_symlink_target_replacement_prevents_trash(self):
        automatic_selection(self.result)
        self.paths[1].unlink()
        self.paths[1].symlink_to(self.paths[0])
        trash = Mock()
        self.assertTrue(trash_selected(self.result, trash=trash).errors)
        trash.assert_not_called()


if __name__ == "__main__":
    unittest.main()
