# SPDX-License-Identifier: GPL-3.0-or-later
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from duplicate_finder.engine import Scanner, ScanOptions
from duplicate_finder.hashing import (Cancellation, Cancelled, FileChanged,
                                      full_hash, partial_hash, identical, checked_open)
from duplicate_finder.model import FileRecord


class EngineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def file(self, name, data=b"exact duplicate content"):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return path

    def scan(self, **options):
        return Scanner(ScanOptions(**options)).scan(self.root)

    def test_different_names_and_extensions(self):
        a = self.file("foto.jpg")
        b = self.file("video.bin")
        c = self.file("other.png")
        r = self.scan()
        self.assertEqual(len(r.groups), 1)
        self.assertEqual({f.path for f in r.groups[0].files}, {a, b, c})
        self.assertFalse(r.selected)
        self.assertEqual(r.redundant_count, 2)
        self.assertEqual(r.potential_bytes, 2 * a.stat().st_size)

    def test_same_size_different_content(self):
        self.file("a", b"abcd")
        self.file("b", b"abce")
        self.assertFalse(self.scan().groups)

    def test_empty_files(self):
        self.file("empty1", b"")
        self.file("empty2", b"")
        r = self.scan()
        self.assertEqual(len(r.groups), 1)
        self.assertEqual(r.potential_bytes, 0)

    def test_large_streamed_files(self):
        a = self.file("large-a", b"")
        with a.open("wb") as stream:
            for _ in range(40):
                stream.write(b"abcdef12" * 131072)
        b = self.file("large-b", b"")
        with a.open("rb") as source, b.open("wb") as dest:
            while block := source.read(1024 * 1024):
                dest.write(block)
        r = self.scan()
        self.assertEqual(len(r.groups), 1)
        self.assertEqual(r.groups[0].files[0].size, 40 * 1024 * 1024)

    def test_sparse_multi_gigabyte_partial_hash(self):
        a = self.file("sparse", b"")
        with a.open("wb") as stream:
            stream.truncate(5 * 1024 ** 3 + 17)
        record = FileRecord.from_stat(a, a.stat())
        self.assertEqual(len(partial_hash(record, Cancellation())), 64)

    def test_nested_and_nonrecursive(self):
        self.file("a")
        self.file("sub/deeper/b")
        self.assertEqual(len(self.scan().groups), 1)
        self.assertFalse(self.scan(recursive=False).groups)

    def test_hidden_files_and_directories(self):
        self.file("a")
        self.file(".hidden")
        self.file(".hidden-dir/file")
        self.assertFalse(self.scan().groups)
        r = self.scan(hidden=True)
        self.assertEqual(len(r.groups[0].files), 3)

    def test_exclusion_patterns(self):
        self.file("a")
        self.file("skip.tmp")
        self.file("cache/copy")
        self.file("backup/a.copy")
        self.assertFalse(self.scan(exclusions=("*.tmp", "cache", "backup/*")).groups)

    def test_symbolic_links_never_followed(self):
        a = self.file("a")
        (self.root / "link").symlink_to(a)
        (self.root / "loop").symlink_to(self.root, target_is_directory=True)
        r = self.scan()
        self.assertFalse(r.groups)
        self.assertEqual(r.symlinks_skipped, 2)

    def test_symbolic_root_rejected(self):
        (self.root / "sub").mkdir()
        link = self.root / "link"
        link.symlink_to(self.root / "sub", target_is_directory=True)
        with self.assertRaises(OSError):
            Scanner().scan(link)

    def test_hardlinks_count_inode_once(self):
        a = self.file("a")
        os.link(a, self.root / "alias")
        r = self.scan()
        self.assertFalse(r.groups)
        self.assertEqual(r.hardlinks_skipped, 1)
        b = self.file("ordinary-copy")
        r = self.scan()
        self.assertEqual(len(r.groups[0].files), 2)
        self.assertEqual(r.potential_bytes, b.stat().st_size)
        linked = next(f for f in r.groups[0].files if f.nlink > 1)
        self.assertEqual(linked.reclaimable, 0)

    def test_permission_error_directory_is_nonfatal(self):
        self.file("a")
        self.file("b")
        folder = self.root / "inaccessible"
        folder.mkdir()
        folder.chmod(0)
        self.addCleanup(lambda: folder.chmod(0o700))
        if os.geteuid() == 0:
            self.skipTest("requires unprivileged user")
        r = self.scan()
        self.assertEqual(len(r.groups), 1)
        self.assertGreater(r.error_count, 0)

    def test_permission_error_file_is_nonfatal(self):
        self.file("a")
        b = self.file("b")
        b.chmod(0)
        self.addCleanup(lambda: b.chmod(0o600))
        if os.geteuid() == 0:
            self.skipTest("requires unprivileged user")
        r = self.scan()
        self.assertFalse(r.groups)
        self.assertGreater(r.error_count, 0)

    def test_modified_during_scan_excluded(self):
        self.file("a")
        b = self.file("b")
        real = partial_hash
        changed = False

        def mutate(record, cancel):
            nonlocal changed
            if not changed:
                b.write_bytes(b"changed data since inventory")
                changed = True
            return real(record, cancel)
        with patch("duplicate_finder.engine.partial_hash", side_effect=mutate):
            r = self.scan()
        self.assertFalse(r.groups)
        self.assertGreater(r.error_count, 0)

    def test_disappeared_during_scan(self):
        self.file("a")
        b = self.file("b")
        real = partial_hash
        removed = False

        def vanish(record, cancel):
            nonlocal removed
            if not removed:
                b.unlink()
                removed = True
            return real(record, cancel)
        with patch("duplicate_finder.engine.partial_hash", side_effect=vanish):
            r = self.scan()
        self.assertFalse(r.groups)
        self.assertGreater(r.error_count, 0)

    def test_cancel_before_scan(self):
        token = Cancellation()
        token.cancel()
        r = Scanner(cancel=token).scan(self.root)
        self.assertTrue(r.cancelled)
        self.assertFalse(r.groups)

    def test_cancel_during_full_hash(self):
        self.file("a")
        self.file("b")
        token = Cancellation()

        def progress(p):
            if p.stage == "Hash completo":
                token.cancel()
        r = Scanner(cancel=token, on_progress=progress).scan(self.root)
        self.assertTrue(r.cancelled)
        self.assertFalse(r.groups)

    def test_hash_collision_still_byte_compared(self):
        self.file("a", b"one!")
        self.file("b", b"two!")
        self.file("c", b"one!")
        with patch("duplicate_finder.engine.partial_hash", return_value="collision"), patch(
                "duplicate_finder.engine.full_hash", return_value="collision"):
            r = self.scan()
        self.assertEqual(len(r.groups), 1)
        self.assertEqual({f.path.name for f in r.groups[0].files}, {"a", "c"})

    def test_same_sample_different_middle_not_duplicate(self):
        content = bytearray(b"a" * (1024 * 1024))
        self.file("a", content)
        content[200000] = 98
        self.file("b", content)
        self.assertFalse(self.scan().groups)

    def test_unique_sizes_skip_hashing(self):
        self.file("a", b"1")
        self.file("b", b"22")
        with patch("duplicate_finder.engine.partial_hash", side_effect=AssertionError("unneeded read")):
            self.assertFalse(self.scan().groups)

    def test_check_after_read_detects_mutation(self):
        a = self.file("a")
        record = FileRecord.from_stat(a, a.stat())
        with self.assertRaises(FileChanged):
            with checked_open(record) as stream:
                stream.read()
                a.write_bytes(b"changes")

    def test_symlink_replacement_rejected(self):
        a = self.file("a")
        b = self.file("b")
        record = FileRecord.from_stat(a, a.stat())
        a.unlink()
        a.symlink_to(b)
        with self.assertRaises(OSError):
            full_hash(record, Cancellation())

    def test_parent_symlink_replacement_rejected(self):
        a = self.file("sub/a")
        record = FileRecord.from_stat(a, a.stat())
        (self.root / "sub").rename(self.root / "moved")
        (self.root / "sub").symlink_to(self.root / "moved", target_is_directory=True)
        with self.assertRaises(OSError):
            full_hash(record, Cancellation())

    def test_missing_root_is_fatal(self):
        with self.assertRaises(OSError):
            Scanner().scan(self.root / "absent")

    def test_non_utf8_filename(self):
        name = os.fsdecode(b"photo-\xff.bin")
        self.file(name)
        self.file("copy")
        self.assertEqual(len(self.scan().groups), 1)

    def test_fifo_is_ignored(self):
        os.mkfifo(self.root / "fifo")
        self.file("a")
        self.file("b")
        self.assertEqual(len(self.scan().groups), 1)

    def test_hash_checks_cancellation_per_block(self):
        a = self.file("a", b"a" * 3 * 1024 * 1024)
        token = Cancellation()
        checks = 0
        original = token.check

        def cancel_second():
            nonlocal checks
            checks += 1
            if checks == 2:
                token.cancel()
            original()
        token.check = cancel_second
        with self.assertRaises(Cancelled):
            full_hash(FileRecord.from_stat(a, a.stat()), token)
        self.assertEqual(checks, 2)

    def test_error_messages_are_bounded(self):
        from duplicate_finder.model import ScanResult
        r = ScanResult()
        for i in range(1000):
            r.add_error(str(i))
        self.assertEqual(r.error_count, 1000)
        self.assertEqual(len(r.errors), 500)


if __name__ == "__main__":
    unittest.main()
