#!/usr/bin/python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Capture the real GTK views using disposable synthetic fixtures."""
from pathlib import Path
import os
import sys
import tempfile
import time
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def main():
    with tempfile.TemporaryDirectory(prefix="DuplicateFinderEjemplo-") as directory:
        root = Path(directory)
        os.environ["XDG_CONFIG_HOME"] = str(root / "config")
        os.environ["XDG_DATA_HOME"] = str(root / "data")
        from duplicate_finder.ui import Application, Gtk, Gdk
        folder = root / "Fotos y videos de prueba"
        folder.mkdir()
        for sub in ("Originales", "Respaldo", "Pendrive"):
            p = folder / sub
            p.mkdir()
            (p / ("Vacaciones.jpg" if sub != "Pendrive" else "Copia con otro nombre.bin")).write_bytes(b"photo" * 100000)
            (p / "Video familiar.mp4").write_bytes(b"video" * 200000)
        app = Application(str(folder))
        app.register(None)
        app.activate()
        window = app.window
        def pump(seconds):
            deadline = time.monotonic() + seconds
            while time.monotonic() < deadline:
                while Gtk.events_pending():
                    Gtk.main_iteration_do(False)
                time.sleep(0.01)
        pump(0.5)
        window.scan_button.clicked()
        deadline = time.monotonic() + 30
        while window.busy or window.populating:
            assert time.monotonic() < deadline
            pump(0.1)
        window.resize(1280, 800)
        for (_, index), column in window.columns.items():
            column.set_fixed_width({0: 75, 1: 210, 2: 235, 3: 90, 4: 155, 5: 65}[index])
        window.auto_button.clicked()
        assert len(window.result.selected) == 4
        for mode, name in (("tree", "screenshot.png"), ("table", "screenshot-table.png")):
            window.stack.set_visible_child_name(mode)
            pump(0.3)
            pixbuf = Gdk.pixbuf_get_from_window(window.get_window(), 0, 0, *window.get_size())
            pixbuf.savev(str(ROOT / "docs" / name), "png", [], [])
        window.close()
        pump(0.1)
        print("Captured real GTK tree and table views with synthetic files")


if __name__ == "__main__":
    main()
