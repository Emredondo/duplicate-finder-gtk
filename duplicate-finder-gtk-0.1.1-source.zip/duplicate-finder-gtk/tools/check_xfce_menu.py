#!/usr/bin/python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Read the actual XFCE menu using Garcon (test-only, no app dependency)."""
import ctypes
from pathlib import Path


def check_menu():
    path = Path("/etc/xdg/menus/xfce-applications.menu")
    if not path.exists():
        print("SKIP XFCE menu: no XFCE menu definition installed")
        return
    garcon = ctypes.CDLL("libgarcon-1.so.0")
    glib = ctypes.CDLL("libglib-2.0.so.0")
    gobject = ctypes.CDLL("libgobject-2.0.so.0")
    class GList(ctypes.Structure):
        pass
    GList._fields_ = [("data", ctypes.c_void_p), ("next", ctypes.POINTER(GList)), ("prev", ctypes.POINTER(GList))]
    pointer = ctypes.POINTER(GList)
    garcon.garcon_menu_new_for_path.argtypes = (ctypes.c_char_p,)
    garcon.garcon_menu_new_for_path.restype = ctypes.c_void_p
    garcon.garcon_menu_load.argtypes = (ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p)
    garcon.garcon_menu_load.restype = ctypes.c_int
    for name in ("garcon_menu_get_items", "garcon_menu_get_menus"):
        function = getattr(garcon, name)
        function.argtypes = (ctypes.c_void_p,)
        function.restype = pointer
    garcon.garcon_menu_item_get_desktop_id.argtypes = (ctypes.c_void_p,)
    garcon.garcon_menu_item_get_desktop_id.restype = ctypes.c_char_p
    glib.g_list_free.argtypes = (pointer,)
    gobject.g_object_unref.argtypes = (ctypes.c_void_p,)
    menu = garcon.garcon_menu_new_for_path(bytes(path))
    try:
        assert garcon.garcon_menu_load(menu, None, None), "XFCE menu could not be loaded"
        ids = set()
        def visit(current):
            items = garcon.garcon_menu_get_items(current)
            node = items
            while node:
                ids.add(garcon.garcon_menu_item_get_desktop_id(node.contents.data))
                node = node.contents.next
            glib.g_list_free(items)
            menus = garcon.garcon_menu_get_menus(current)
            node = menus
            while node:
                visit(node.contents.data)
                node = node.contents.next
            glib.g_list_free(menus)
        visit(menu)
        assert b"duplicate-finder-gtk.desktop" in ids, "Application missing from the XFCE menu"
        print("PASS actual XFCE applications menu discovers duplicate-finder-gtk.desktop (Garcon)")
    finally:
        gobject.g_object_unref(menu)


if __name__ == "__main__":
    check_menu()
