# Actualización 0.1.2 — 2026-11-13

Se agregó eliminación definitiva, siempre tras confirmación. Pasaron 63 pruebas automatizadas y las pruebas de interfaz GTK/GIO, incluyendo cancelación, borrado real de archivos temporales, conservación de una copia y ausencia de archivos adicionales en la papelera. La instalación en una imagen Debian 13 limpia sigue pendiente. Las verificaciones de versiones anteriores figuran a continuación.

# Actualización 0.1.1

Se reemplazaron los dos selectores por el explorador completo de carpetas de GTK. Se verificaron navegación, selección y cancelación en pantalla virtual, además de la suite de 57 pruebas. Las comprobaciones de la versión 0.1.0 se conservan a continuación como referencia.

# Informe de verificación — Duplicate Finder GTK 0.1.0

**Fecha:** 12 de noviembre de 2026. **Destino:** Debian 13 Trixie, GTK 3, escritorio XFCE. **Resultado:** código completo, pruebas satisfactorias y DEB generado. No se publicó en GitHub.

## Entorno y alcance

Se trabajó en Debian GNU/Linux 13.7 Trixie, amd64, Python 3.13.5, PyGObject 3.50.0 y GTK 3.24.49. El paquete es `Architecture: all`: contiene exclusivamente Python, documentación e icono SVG. No se modificaron otros proyectos ni archivos de referencia.

La instalación y desinstalación se ejecutaron dentro de un espacio de nombres con bubblewrap: sistema principal montado de sólo lectura, directorios de instalación y base de dpkg copiados a una carpeta temporal. Las dependencias se reutilizan del Debian 13 disponible. Se utilizó Xvfb para pruebas gráficas; no se instaló el programa en el sistema principal.

Se intentó preparar además una imagen Debian mínima mediante mmdebstrap. El entorno permite mapear un único UID/GID, y la extracción falló al asignar grupos de paquetes del sistema. **No se certificó una instalación en una imagen Debian 13 limpia ni una sesión XFCE completa iniciada desde cero.** Se comprobó el menú real de XFCE mediante Garcon y se abrió la entrada de escritorio instalada en una pantalla virtual.

## Pruebas automatizadas

`python3 -m unittest discover -s tests -v`: **57 pruebas aprobadas, sin fallos ni omisiones**. Registro: `tests.log`.

Cobertura funcional:

- Igualdad con nombres y extensiones diferentes; distintos bytes con igual tamaño.
- Archivos vacíos, archivos de 40 MiB, muestras de un archivo disperso de más de 5 GiB.
- Subcarpetas, modo no recursivo, ocultos y exclusiones por patrones.
- Enlaces simbólicos, bucles, sustitución de carpetas por enlaces y enlaces duros.
- Permisos reales denegados, archivos modificados y desaparecidos durante el análisis.
- Cancelación en inventario/hashes y entre bloques.
- Colisiones de hash simuladas: archivos distintos nunca se aceptan sin comparación byte a byte.
- Los tres criterios de conservación, prioridad recursiva, alternativa por antigüedad y empates deterministas.
- Selección manual y protección contra seleccionar todas las copias, incluso si se manipula el modelo.
- Error de papelera: archivo intacto, grupo detenido; otros grupos pueden continuar.
- Copia conservada modificada, ausente o sustituida; cambio entre dos operaciones.
- Cancelación de papelera, actualizaciones por archivo y preferencias XDG atómicas con permiso 0600.

`tests/gui_smoke.py`: **todas las comprobaciones GTK/GIO aprobadas**. Registro: `gui-tests.log`.

- Inicio real de GTK 3, análisis en trabajador y latidos del hilo principal durante el proceso.
- Resultados exactos inicialmente sin marcar, tabla ordenada y selección compartida con árbol.
- Conservación por los tres criterios, portapapeles, propiedades y creación del selector de aplicaciones.
- Asociación MIME real hacia una aplicación auxiliar temporal y apertura efectiva del archivo; apertura con otra aplicación elegida desde el selector.
- Confirmación cancelada sin cambios y envío real mediante GIO a una papelera aislada, con archivo y `.trashinfo`, conservando las demás copias.
- Actualización de resultados, persistencia/restauración de preferencias, cancelación y cierre.

## Archivos mayores de 4 GiB

`tools/benchmark_large.py`: dos archivos de **5.368.709.137 bytes cada uno**, SHA-256 completo y comparación byte a byte. Grupo correcto y sin incidencias. Tiempo medido: **48,094 segundos**. Memoria residente máxima del proceso: **22.624 KiB**, aproximadamente **22,1 MiB**. Registro: `large-files.log`.

Los archivos de esta prueba son dispersos: demuestra manejo de tamaños grandes y lecturas con memoria acotada; **no mide el rendimiento de un disco físico** ni representa un benchmark general de fotografías o videos. El inventario requiere memoria proporcional a la cantidad de archivos.

## Paquete Debian

Artefacto: `duplicate-finder-gtk_0.1.0_all.deb`.

- `dpkg-deb --info` y `--contents`: estructura válida, rutas estándar y propietario root dentro del paquete.
- Dependencias: Python 3 >= 3.11, python3-gi >= 3.42, GTK 3 por gir1.2-gtk-3.0 >= 3.24 y GIO/GLib por gir1.2-glib-2.0 >= 1.70. `gvfs` recomendado.
- Sin scripts de descarga ni scripts de mantenimiento propios. APT resuelve dependencias.
- `desktop-file-validate`: aprobado; `Categories=Utility;FileTools;`.
- `lintian`: aprobado **sin errores ni advertencias**. Registro vacío: `lintian.log`.
- Construcción reproducible: dos construcciones consecutivas con idénticas entradas y `SOURCE_DATE_EPOCH` producen el mismo SHA-256. Las sumas de los artefactos finales se entregan en `SHA256SUMS`.
- `apt install` dentro del Debian 13 aislado: aprobado; sin descargar dependencias adicionales, ya disponibles en ese entorno.
- `duplicate-finder-gtk --version`: `Duplicate Finder GTK 0.1.0`.
- `dpkg --verify`: sin diferencias.
- Garcon carga `/etc/xdg/menus/xfce-applications.menu` y encuentra `duplicate-finder-gtk.desktop`.
- La entrada `.desktop` instalada abre una ventana GTK real. El tema de iconos carga el icono propio a 64 px.
- Cierre normal de la aplicación instalada y guardado de preferencias: aprobado.
- `apt remove`: aprobado; desaparecen ejecutable, módulos, entrada del menú e icono. Las preferencias se conservan.

Registro completo de instalación/desinstalación: `package-install.log`. El aviso de `setpriv` del desencadenador **man-db** corresponde al UID de servicio no representable en este entorno de pruebas de un solo usuario. APT termina con éxito; el manual está incluido. Se observaron avisos del tema/pixbuf y servicios de sesión ausentes al ejecutar GTK sin escritorio completo; el icono instalado y las operaciones verificadas funcionan.

## Revisión y límites conocidos

El código está dividido en interfaz, búsqueda, hashes/verificación, modelo/selección, papelera y configuración. Se revisaron rutas de error, cancelación, cierre de descriptores y ausencia de borrado permanente. Las capturas `screenshot.png` y `screenshot-table.png` muestran ventanas reales con archivos sintéticos.

- GIO mueve archivos por ruta: no proporciona una transacción atómica frente a un escritor concurrente o un proceso malicioso. Se verifican bytes y metadatos inmediatamente antes de cada traslado. Deben detenerse las escrituras concurrentes. Más detalle en `SECURITY.md`.
- La cancelación se comprueba entre bloques de 1 MiB y operaciones; una llamada al sistema bloqueada puede retrasarla.
- El espacio es una estimación lógica y no se libera hasta vaciar la papelera. Enlaces duros, archivos dispersos, reflinks y compresión requieren interpretación conservadora.
- No se han certificado Ubuntu, otras distribuciones ni una instalación Debian desde cero. La interfaz está en español; algunos textos del toolkit dependen de la localización del sistema.
- El flujo de GitHub Actions está preparado, pero no se ejecutó en GitHub; no se publicó ningún repositorio ni release. La publicación pública requiere definir propietario y confirmación.
