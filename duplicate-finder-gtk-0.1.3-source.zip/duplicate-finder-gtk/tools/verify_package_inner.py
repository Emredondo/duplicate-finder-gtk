#!/usr/bin/python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Only invoked by verify_package.py inside its read-only-host namespace."""
from pathlib import Path
import os
import subprocess
import sys
import time


def run(*args):
    print("RUN", " ".join(args), flush=True)
    subprocess.run(args, check=True)


def main():
    if not Path("/mnt").is_dir() or not Path("/tmp/project/dist").is_dir():
        raise SystemExit("Only run through verify_package.py")
    package = "/tmp/project/dist/duplicate-finder-gtk_0.1.3_all.deb"
    run("apt", "install", "-y", "--no-install-recommends", package)
    run("duplicate-finder-gtk", "--version")
    run("dpkg", "--verify", "duplicate-finder-gtk")
    run("desktop-file-validate", "/usr/share/applications/duplicate-finder-gtk.desktop")
    run("/usr/bin/python3", "-B", "-c", 'import sys; sys.path.insert(0,"/usr/share/duplicate-finder-gtk"); from duplicate_finder.ui import Application; print("Installed GTK import passed")')
    from gi.repository import Gio
    desktop = Gio.DesktopAppInfo.new_from_filename("/usr/share/applications/duplicate-finder-gtk.desktop")
    assert desktop and desktop.get_executable() == "duplicate-finder-gtk"
    assert "Utility;FileTools;" == desktop.get_categories()
    assert desktop.get_icon().to_string() == "duplicate-finder-gtk"
    assert Path("/usr/share/icons/hicolor/scalable/apps/duplicate-finder-gtk.svg").is_file()
    from check_xfce_menu import check_menu
    check_menu()
    if os.environ.get("DISPLAY"):
        import gi
        gi.require_version("Gtk", "3.0")
        gi.require_version("Gdk", "3.0")
        from gi.repository import Gtk, Gdk
        assert Gtk.init_check()[0]
        theme = Gtk.IconTheme.get_default()
        theme.rescan_if_needed()
        icon = theme.load_icon("duplicate-finder-gtk", 64, 0)
        assert icon.get_width() == 64
        # Launch the actual installed application through its desktop entry.
        desktop.launch([], None)
        deadline = time.monotonic() + 10
        window_line = None
        while time.monotonic() < deadline:
            listing = subprocess.check_output(["xwininfo", "-root", "-tree"], text=True)
            window_line = next((line for line in listing.splitlines() if '"Duplicate Finder GTK"' in line), None)
            if window_line:
                break
            time.sleep(0.1)
        assert window_line, "Installed .desktop launch did not create a window"
        print("PASS installed desktop entry launches a real GTK window; icon resolves")
        window_id = int(window_line.split()[0], 16)
        # X11 WM_DELETE_WINDOW is the same graceful close request as a window manager.
        import ctypes
        x11 = ctypes.CDLL("libX11.so.6")
        x11.XOpenDisplay.restype = ctypes.c_void_p
        x11.XInternAtom.argtypes = (ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int)
        x11.XInternAtom.restype = ctypes.c_ulong
        x11.XSendEvent.argtypes = (ctypes.c_void_p, ctypes.c_ulong, ctypes.c_int, ctypes.c_long, ctypes.c_void_p)
        x11.XFlush.argtypes = (ctypes.c_void_p,)
        x11.XCloseDisplay.argtypes = (ctypes.c_void_p,)
        class ClientMessage(ctypes.Structure):
            _fields_ = [("type", ctypes.c_int), ("serial", ctypes.c_ulong), ("send_event", ctypes.c_int),
                        ("display", ctypes.c_void_p), ("window", ctypes.c_ulong),
                        ("message_type", ctypes.c_ulong), ("format", ctypes.c_int), ("data", ctypes.c_long * 5)]
        display = x11.XOpenDisplay(None)
        event = ClientMessage()
        event.type, event.send_event, event.display, event.window, event.format = 33, 1, display, window_id, 32
        event.message_type = x11.XInternAtom(display, b"WM_PROTOCOLS", 0)
        event.data[0] = x11.XInternAtom(display, b"WM_DELETE_WINDOW", 0)
        x11.XSendEvent(display, window_id, 0, 0, ctypes.byref(event))
        x11.XFlush(display)
        x11.XCloseDisplay(display)
        preferences = Path("/tmp/df-config/duplicate-finder-gtk/preferences.json")
        deadline = time.monotonic() + 10
        while not preferences.exists() and time.monotonic() < deadline:
            time.sleep(0.1)
        assert preferences.exists(), "Installed app did not close and persist preferences"
    else:
        print("SKIP actual desktop launch: no DISPLAY")
        preferences = Path("/tmp/df-config/duplicate-finder-gtk/preferences.json")
        preferences.parent.mkdir(parents=True)
        preferences.write_text('{"view":"tree"}')
    saved = preferences.read_bytes()
    run("apt", "remove", "-y", "duplicate-finder-gtk")
    assert not Path("/usr/bin/duplicate-finder-gtk").exists()
    assert not Path("/usr/share/duplicate-finder-gtk").exists()
    assert not Path("/usr/share/applications/duplicate-finder-gtk.desktop").exists()
    assert not Path("/usr/share/icons/hicolor/scalable/apps/duplicate-finder-gtk.svg").exists()
    assert preferences.read_bytes() == saved
    print("PASS APT install, dependency resolution, integrity, desktop launch, removal and retained preferences")


if __name__ == "__main__":
    main()
