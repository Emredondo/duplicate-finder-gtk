# SPDX-License-Identifier: GPL-3.0-or-later
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from duplicate_finder import config


class ConfigTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "nested/preferences.json"

    def test_missing_returns_defaults(self):
        self.assertEqual(config.load(self.path), config.DEFAULTS)

    def test_atomic_roundtrip_permissions(self):
        settings = config.load(self.path)
        settings.update(view="table", recursive=False, columns={"tree:1": 280}, x=10, y=20)
        config.save(settings, self.path)
        self.assertEqual(config.load(self.path), settings)
        self.assertEqual(self.path.stat().st_mode & 0o777, 0o600)
        self.assertEqual(list(self.path.parent.iterdir()), [self.path])

    def test_corrupt_and_wrong_types(self):
        self.path.parent.mkdir()
        for value in ("not json", "[]", '{"view": "garbage", "width": "a", "hidden": 1, "columns": {"a": "bad"}}'):
            self.path.write_text(value)
            values = config.load(self.path)
            self.assertEqual(values["view"], "tree")
            self.assertEqual(values["width"], 1120)
            self.assertFalse(values["hidden"])
            self.assertEqual(values["columns"], {})

    def test_xdg_absolute_path(self):
        with patch.dict(os.environ, {"XDG_CONFIG_HOME": self.temp.name}):
            self.assertEqual(config.config_path(), Path(self.temp.name) / "duplicate-finder-gtk/preferences.json")

    def test_xdg_relative_path_ignored(self):
        with patch.dict(os.environ, {"XDG_CONFIG_HOME": "relative"}):
            self.assertEqual(config.config_path(), Path.home() / ".config/duplicate-finder-gtk/preferences.json")

    def test_limits(self):
        self.path.parent.mkdir()
        self.path.write_text('{"width": 9999999, "height": -1, "columns": {"a": -2}, "criterion": "bad"}')
        values = config.load(self.path)
        self.assertEqual(values["width"], 4000)
        self.assertEqual(values["height"], 550)
        self.assertEqual(values["columns"]["a"], 45)
        self.assertEqual(values["criterion"], "oldest")
