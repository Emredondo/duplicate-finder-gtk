#!/usr/bin/python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Real GTK/GIO integration against temporary fixtures; requires a display."""
import os
import json
from pathlib import Path
import sys
import tempfile
import time
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def main():
    with tempfile.TemporaryDirectory(prefix=".gui-test-", dir=ROOT) as directory:
        base = Path(directory)
        os.environ["XDG_CONFIG_HOME"] = str(base / "config")
        os.environ["XDG_DATA_HOME"] = str(base / "data")
        from duplicate_finder.ui import Application, Gtk, GLib, Gio, Gdk
        assert Gtk.init_check()[0], "GTK requires a working display (use xvfb-run)"
        fixtures = base / "fixtures"
        fixtures.mkdir()
        for number, name in enumerate(("old.jpg", "new.mp4", "nested/copy.bin"), 1):
            path = fixtures / name
            path.parent.mkdir(exist_ok=True)
            path.write_bytes(b"exact content " * 10000)
            os.utime(path, ns=(number * 1000000000, number * 1000000000))
        (fixtures / "different.bin").write_bytes(b"other content " * 10000)
        unusual = fixtures / os.fsdecode(b"odd-\xff")
        unusual.write_bytes(b"unique odd file")

        def until(condition, timeout=20):
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                while Gtk.events_pending():
                    Gtk.main_iteration_do(False)
                if condition():
                    return
                time.sleep(0.01)
            raise AssertionError("GTK integration timed out")

        app = Application(str(fixtures))
        app.register(None)
        app.activate()
        window = app.window
        until(lambda: window.folder_button.get_filename() == str(fixtures))
        # Both buttons open the full folder browser immediately. Navigation and
        # cancellation must retain the same semantics as an ordinary file manager.
        for button in (window.folder_button, window.priority):
            original = button.get_filename()
            button.clicked()
            until(lambda: any(isinstance(w, Gtk.FileChooserDialog) and w.get_visible()
                              for w in Gtk.Window.list_toplevels()))
            chooser = next(w for w in Gtk.Window.list_toplevels()
                           if isinstance(w, Gtk.FileChooserDialog) and w.get_visible())
            chooser.set_current_folder(str(fixtures / "nested"))
            until(lambda: chooser.get_current_folder() == str(fixtures / "nested"))
            chooser.response(Gtk.ResponseType.ACCEPT)
            until(lambda: button.get_filename() == str(fixtures / "nested"))
            button.clicked()
            until(lambda: any(isinstance(w, Gtk.FileChooserDialog) and w.get_visible()
                              for w in Gtk.Window.list_toplevels()))
            chooser = next(w for w in Gtk.Window.list_toplevels()
                           if isinstance(w, Gtk.FileChooserDialog) and w.get_visible())
            chooser.response(Gtk.ResponseType.CANCEL)
            assert button.get_filename() == str(fixtures / "nested")
            if original:
                button.set_filename(original)
            else:
                button.unselect_all()
        print("PASS direct folder browser navigation, selection and cancellation")
        heartbeat = [0]
        heartbeat_id = GLib.timeout_add(5, lambda: (heartbeat.__setitem__(0, heartbeat[0] + 1) or True))
        window.scan_button.clicked()
        until(lambda: not window.busy and not window.populating)
        assert len(window.result.groups) == 1
        assert len(window.table_store) == 3
        assert not window.result.selected
        assert heartbeat[0] > 0
        assert window.progress.get_text() == "Completado"
        assert window.views["tree"].get_columns()[2].get_title() == "Ubicación"
        print("PASS GTK startup, threaded scan, heartbeat, exact results, unselected defaults")

        window.stack.set_visible_child_name("table")
        window.table_store.set_sort_column_id(1, Gtk.SortType.DESCENDING)
        window.auto_button.clicked()
        assert len(window.result.selected) == 2
        assert fixtures / "old.jpg" not in window.result.selected
        for row in window.table_store:
            assert row[0] == (window.records[row[6]].path in window.result.selected)
        for parent in window.tree_store:
            for child in parent.iterchildren():
                assert child[0] == (window.records[child[6]].path in window.result.selected)
        assert window.trash_button.get_sensitive()
        window.clear_button.clicked()
        window.criterion.set_active_id("newest")
        window.auto_button.clicked()
        assert fixtures / "nested/copy.bin" not in window.result.selected
        window.clear_button.clicked()
        window.priority.set_filename(str(fixtures / "nested"))
        until(lambda: window.priority.get_filename() == str(fixtures / "nested"))
        window.criterion.set_active_id("priority")
        window.auto_button.clicked()
        assert fixtures / "nested/copy.bin" not in window.result.selected
        print("PASS sorted table/tree selection synchronization and all three keep criteria")

        record = next(iter(window.records.values()))
        window.copy_path(record)
        assert Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD).wait_for_text() == str(record.path)
        with patch.object(Gio.AppInfo, "launch_default_for_uri_async") as launch:
            window.open_file(record)
            assert launch.call_args[0][0] == Gio.File.new_for_path(str(record.path)).get_uri()
        with patch.object(window, "notice") as properties:
            window.properties(record)
            assert "Inodo:" in properties.call_args[0][1]
        view = window.views["table"]
        view.set_cursor(Gtk.TreePath.new_from_string("0"))
        with patch.object(Gtk.Menu, "popup_at_widget") as popup:
            assert window.context_menu(view, None)
            popup.assert_called_once()
        chooser = Gtk.AppChooserDialog.new(window, Gtk.DialogFlags.MODAL,
                                           Gio.File.new_for_path(str(record.path)))
        chooser.get_widget().set_show_other(True)
        chooser.destroy()
        print("PASS clipboard, GIO opening dispatch, properties, context menu, application chooser")

        # A real MIME handler writes its received filename to our temporary fixture.
        marker = base / "opened.json"
        helper = base / "mime-handler.py"
        helper.write_text("import json,sys\nfrom pathlib import Path\n" +
                          f"Path({str(marker)!r}).write_text(json.dumps(sys.argv[1:]))\n")
        applications = base / "data/applications"
        applications.mkdir(parents=True, exist_ok=True)
        entry = applications / "df-test-handler.desktop"
        entry.write_text('[Desktop Entry]\nType=Application\nName=Temporary test handler\n' +
                         f'Exec=/usr/bin/python3 "{helper}" %f\nTerminal=false\nNoDisplay=true\n')
        handler = Gio.DesktopAppInfo.new_from_filename(str(entry))
        content_type = Gio.File.new_for_path(str(record.path)).query_info(
            "standard::content-type", Gio.FileQueryInfoFlags.NONE, None).get_content_type()
        assert handler.set_as_default_for_type(content_type)
        window.open_file(record)
        until(marker.exists)
        assert json.loads(marker.read_text()) == [str(record.path)]
        marker.unlink()
        with patch.object(Gtk.AppChooserDialog, "run", return_value=Gtk.ResponseType.OK), patch.object(
                Gtk.AppChooserDialog, "get_app_info", return_value=handler):
            window.open_with(record)
        until(marker.exists)
        assert json.loads(marker.read_text()) == [str(record.path)]
        print("PASS actual MIME association and open-with launch to an isolated test application")

        window.clear_button.clicked()
        selected_path = fixtures / "new.mp4"
        selected_record = next(f for f in window.records.values() if f.path == selected_path)
        window.change_selection(selected_record, True)
        with patch.object(Gtk.MessageDialog, "run", return_value=Gtk.ResponseType.CANCEL):
            window.confirm_trash()
        assert selected_path.exists() and not window.busy
        with patch.object(Gtk.MessageDialog, "run", return_value=Gtk.ResponseType.ACCEPT):
            window.confirm_trash()
        until(lambda: not window.busy and not window.populating)
        assert not selected_path.exists(), (window.result.errors, window.status.get_text(), window.result.selected)
        assert (fixtures / "old.jpg").exists()
        assert (fixtures / "nested/copy.bin").exists()
        assert len(window.table_store) == 2
        trashed = list((base / "data/Trash/files").iterdir())
        assert len(trashed) == 1
        assert trashed[0].read_bytes() == b"exact content " * 10000
        assert len(list((base / "data/Trash/info").glob("*.trashinfo"))) == 1
        print("PASS cancelled confirmation, real GIO trash, retained copies, incremental results")

        # Permanent deletion is separate from trash and requires explicit acceptance.
        delete_path = fixtures / "nested/copy.bin"
        delete_record = next(f for f in window.records.values() if f.path == delete_path)
        window.change_selection(delete_record, True)
        assert window.delete_button.get_sensitive()
        with patch.object(Gtk.MessageDialog, "run", return_value=Gtk.ResponseType.CANCEL):
            window.confirm_delete()
        assert delete_path.exists() and not window.busy
        with patch.object(Gtk.MessageDialog, "run", return_value=Gtk.ResponseType.ACCEPT):
            window.confirm_delete()
        until(lambda: not window.busy and not window.populating)
        assert not delete_path.exists(), window.result.errors
        assert (fixtures / "old.jpg").exists()
        assert len(list((base / "data/Trash/files").iterdir())) == 1
        assert not window.result.groups
        print("PASS permanent deletion confirmation, real removal, retained copy and no extra trash")

        window.clear_button.clicked()
        window.stack.set_visible_child_name("table")
        window.persist()
        from duplicate_finder import config
        saved = config.load()
        assert saved["view"] == "table"
        assert saved["criterion"] == "priority"
        assert saved["folder"] == str(fixtures)
        window.restore_defaults()
        assert window.stack.get_visible_child_name() == "tree"
        assert window.criterion.get_active_id() == "oldest"
        assert not window.hidden.get_active()
        print("PASS XDG preference persistence and restore defaults")

        bulk = base / "bulk"
        bulk.mkdir()
        for i in range(320):
            (bulk / f"copy-{i:04d}.dat").write_bytes(b"bulk content")
        window.folder_button.set_filename(str(bulk))
        until(lambda: window.folder_button.get_filename() == str(bulk))
        window.scan_button.clicked()
        until(lambda: not window.busy and not window.populating)
        assert len(window.table_store) == 320
        window.auto_button.clicked()
        assert window.populating, "large selection must be applied in GTK idle chunks"
        until(lambda: not window.populating)
        assert len(window.result.selected) == 319
        assert sum(row[0] for row in window.table_store) == 319
        window.clear_button.clicked()
        until(lambda: not window.populating)
        assert not window.result.selected
        assert sum(row[0] for row in window.table_store) == 0
        print("PASS chunked GTK rendering and shared selection of 320 duplicate files")

        # Let a large group start deleting and cancel from the live GTK loop.
        window.auto_button.clicked()
        until(lambda: not window.populating)
        with patch.object(Gtk.MessageDialog, "run", return_value=Gtk.ResponseType.ACCEPT):
            window.delete_button.clicked()
        until(lambda: len(window.table_store) < 320)
        window.cancel_button.clicked()
        until(lambda: not window.busy)
        remaining = {f.path for f in window.result.groups[0].files}
        assert remaining == set(bulk.iterdir()) and 1 < len(remaining) < 320
        assert len(window.table_store) == len(remaining)
        assert window.tree_store.iter_n_children(window.tree_store.get_iter_first()) == len(remaining)
        assert len(window.result.selected) == len(remaining) - 1
        assert window.progress.get_text() == "Cancelado"

        pairs = base / "pairs"
        pairs.mkdir()
        for i in range(1000):
            for name in ("a", "b"):
                (pairs / f"{i:04d}-{name}").write_bytes(str(i).encode())
        window.folder_button.set_filename(str(pairs))
        window.scan_button.clicked()
        until(lambda: not window.busy and not window.populating)
        window.auto_button.clicked()
        until(lambda: not window.populating)
        keepers = set(pairs.iterdir()) - window.result.selected
        assert len(keepers) == 1000
        beats = [time.monotonic()]
        monitor = GLib.timeout_add(20, lambda: beats.append(time.monotonic()) or True)
        with patch.object(Gtk.MessageDialog, "run", return_value=Gtk.ResponseType.ACCEPT):
            window.delete_button.clicked()
        until(lambda: not window.busy, timeout=60)
        beats.append(time.monotonic())
        GLib.source_remove(monitor)
        gap = max(b - a for a, b in zip(beats, beats[1:]))
        assert len(beats) > 2 and gap < 1.0, f"GTK stalled for {gap:.3f}s"
        assert set(pairs.iterdir()) == keepers and not window.result.errors
        assert not window.result.groups and not window.result.selected
        assert len(window.table_store) == len(window.tree_store) == 0
        print(f"PASS bulk deletion of 1,000 pairs, longest GTK pause {gap:.3f}s; partial cancellation")

        # Force cancellation early enough that it cannot race a tiny scan completion.
        window.folder_button.set_filename(str(fixtures))
        until(lambda: window.folder_button.get_filename() == str(fixtures))
        window.scan_button.clicked()
        window.cancel_button.clicked()
        until(lambda: not window.busy and not window.populating)
        assert window.result.cancelled
        assert not window.result.groups
        GLib.source_remove(heartbeat_id)
        if os.environ.get("DUPLICATE_FINDER_SCREENSHOT"):
            # Re-scan for a useful real application screenshot.
            window.scan_button.clicked()
            until(lambda: not window.busy and not window.populating)
            window.auto_button.clicked()
            until(lambda: Gtk.events_pending() is False, timeout=2)
            gdk_window = window.get_window()
            pixbuf = Gdk.pixbuf_get_from_window(gdk_window, 0, 0, *window.get_size())
            pixbuf.savev(os.environ["DUPLICATE_FINDER_SCREENSHOT"], "png", [], [])
        window.close()
        until(lambda: not window.get_visible())
        print("PASS responsive cancellation and clean shutdown")
        print("GTK/GIO integration: ALL CHECKS PASSED")


if __name__ == "__main__":
    main()
