# Modelo de seguridad

## Garantías implementadas

- Hay dos acciones distintas: papelera mediante `Gio.File.trash` y eliminación definitiva mediante `os.unlink` sobre un descriptor de directorio validado. La eliminación definitiva requiere confirmación explícita, con Cancelar por defecto.
- Confirmación explícita de cantidad y estimación de espacio; opción predeterminada: cancelar.
- Selección automática y manual conservan una copia; el servicio de papelera valida de nuevo esa condición aunque se manipule el modelo.
- Antes de cada grupo se comprueban todos sus miembros y se comparan sus bytes con una copia conservada.
- Antes de cada operación se comprueban otra vez los metadatos de los miembros restantes, se comparan target y copia conservada y se repiten las comprobaciones de ruta inmediatamente antes de GIO.
- Se detectan sustituciones, desapariciones y cambios ordinarios, incluso cuando se restaura la fecha de modificación, mediante la fecha de cambio del inodo.
- No se sigue ningún componente simbólico de las rutas al inventariar, leer o verificar; se usan descriptores de directorio, `O_NOFOLLOW`, `O_NONBLOCK` y comprobaciones `fstat`. Un archivo sustituido por una FIFO no puede bloquear la apertura esperando un escritor.
- Descriptores y objetos de archivo se cierran también cuando hay error o cancelación.
- Errores de lectura excluyen el archivo afectado. Errores de verificación, papelera o eliminación detienen el grupo afectado; la papelera nunca recurre automáticamente a eliminación permanente.
- Los grupos cancelados o parcialmente analizados no se ofrecen para eliminación.
- No se invoca un intérprete de órdenes con rutas de usuario; apertura y MIME se delegan a GIO.
- Las preferencias se guardan de forma atómica y con permiso 0600. Los nombres no UTF-8 se conservan internamente y se muestran con caracteres de sustitución.

## Límites prácticos

GIO envía a la papelera por **ruta**, y la eliminación definitiva usa `unlink` relativo a un directorio abierto; ninguna operación garantiza condicionalmente que el nombre siga refiriéndose al archivo verificado. Existe una ventana entre la última comprobación y el traslado, y una copia conservada puede cambiar después de comprobarla. Tampoco puede garantizarse seguridad ante manipulación hostil de directorios o metadatos desde otro proceso, fallos físicos del disco o comportamientos no habituales de sistemas de archivos remotos. No es un sustituto de una copia de seguridad. Detenga las escrituras concurrentes antes de confirmar.

La cancelación se consulta entre archivos y bloques de 1 MiB. Una llamada al sistema bloqueada por el dispositivo o el montaje puede retrasarla; GIO termina la operación de papelera ya iniciada antes de cancelar la siguiente. Se usa un solo trabajador para evitar lecturas en paralelo sobre discos mecánicos.

El espacio mostrado es lógico. La papelera no libera bloques inmediatamente. Archivos dispersos, compresión y reflinks cambian el cálculo real. Los inodos con enlaces duros se cuentan una sola vez y aportan cero al cálculo conservador de recuperación. Una copia conservada puede tener varios nombres físicos no mostrados; no se borran esos nombres adicionales.

Las incidencias se mantienen en memoria (hasta 500 detalles, con contador total); no se persisten rutas privadas en registros del programa. Los fallos internos inesperados se escriben en stderr mediante logging. Las preferencias sí contienen las últimas carpetas seleccionadas y pertenecen al usuario.

## Información de referencia

La operación de papelera sigue la [API GIO File.trash](https://docs.gtk.org/gio/method.File.trash.html). Las ubicaciones del paquete siguen las convenciones de [archivos de Debian](https://www.debian.org/doc/debian-policy/ch-files.html).
