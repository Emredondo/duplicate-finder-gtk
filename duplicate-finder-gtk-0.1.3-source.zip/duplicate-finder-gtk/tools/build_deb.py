#!/usr/bin/python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Build a reproducible architecture-independent Debian binary without root."""
from pathlib import Path
import gzip
import hashlib
import os
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent.parent
VERSION = "0.1.3"
EPOCH = int(os.environ.get("SOURCE_DATE_EPOCH", "1794441600"))
CONTROL = f"""Package: duplicate-finder-gtk
Version: {VERSION}
Section: utils
Priority: optional
Architecture: all
Maintainer: Duplicate Finder GTK contributors <duplicate-finder-gtk@users.noreply.github.com>
Depends: python3 (>= 3.11), python3-gi (>= 3.42), gir1.2-gtk-3.0 (>= 3.24), gir1.2-glib-2.0 (>= 1.70)
Recommends: gvfs
Description: GTK utility for finding exact duplicate files
 Finds duplicate files by content, using size filtering, partial and full
 SHA-256 hashes and byte-for-byte verification. Keeps at least one copy
 per group and sends selected copies to the trash or, after confirmation,
 permanently deletes them.
 Supports tree and sortable table views, exclusions and XDG preferences.
"""


def copy(source, dest):
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, dest)
    dest.chmod(0o644)


def compressed(data, dest):
    dest.parent.mkdir(parents=True, exist_ok=True)
    with dest.open("wb") as stream:
        with gzip.GzipFile(filename="", mode="wb", fileobj=stream, mtime=0) as compressor:
            compressor.write(data)
    dest.chmod(0o644)


def build():
    out = ROOT / "dist"
    out.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="duplicate-finder-build-") as directory:
        stage = Path(directory)
        app = stage / "usr/share/duplicate-finder-gtk/duplicate_finder"
        for source in sorted((ROOT / "duplicate_finder").glob("*.py")):
            copy(source, app / source.name)
        launcher = stage / "usr/bin/duplicate-finder-gtk"
        launcher.parent.mkdir(parents=True)
        launcher.write_text('#!/usr/bin/python3\nimport sys\nsys.dont_write_bytecode = True\nsys.path.insert(0, "/usr/share/duplicate-finder-gtk")\nfrom duplicate_finder.__main__ import main\nsys.exit(main())\n')
        launcher.chmod(0o755)
        copy(ROOT / "data/duplicate-finder-gtk.desktop", stage / "usr/share/applications/duplicate-finder-gtk.desktop")
        copy(ROOT / "data/duplicate-finder-gtk.svg", stage / "usr/share/icons/hicolor/scalable/apps/duplicate-finder-gtk.svg")
        docs = stage / "usr/share/doc/duplicate-finder-gtk"
        for name in ("README.md", "LICENSE", "docs/SECURITY.md", "docs/VERIFICATION.md"):
            copy(ROOT / name, docs / Path(name).name)
        readme = docs / "README.md"
        readme.write_text(readme.read_text().replace("(docs/INSTALL.md)", "(README.Debian)")
                          .replace("(docs/SECURITY.md)", "(SECURITY.md)")
                          .replace("(docs/VERIFICATION.md)", "(VERIFICATION.md)")
                          .replace("(CHANGELOG.md)", "(changelog.gz)"))
        copy(ROOT / "docs/INSTALL.md", docs / "README.Debian")
        copy(ROOT / "debian/copyright", docs / "copyright")
        compressed((ROOT / "CHANGELOG.md").read_bytes(), docs / "changelog.gz")
        compressed((ROOT / "debian/changelog").read_bytes(), docs / "changelog.Debian.gz")
        compressed((ROOT / "data/duplicate-finder-gtk.1").read_bytes(), stage / "usr/share/man/man1/duplicate-finder-gtk.1.gz")
        control = stage / "DEBIAN"
        control.mkdir()
        installed_size = sum(p.stat().st_size for p in stage.rglob("*") if p.is_file())
        (control / "control").write_text(CONTROL + f"Installed-Size: {(installed_size + 1023) // 1024}\n")
        checksums = []
        for path in sorted(stage.rglob("*")):
            if path.is_file() and control not in path.parents:
                checksums.append(f"{hashlib.md5(path.read_bytes()).hexdigest()}  {path.relative_to(stage)}")
        (control / "md5sums").write_text("\n".join(checksums) + "\n")
        for path in stage.rglob("*"):
            if path.is_dir():
                path.chmod(0o755)
            os.utime(path, (EPOCH, EPOCH))
        os.utime(stage, (EPOCH, EPOCH))
        target = out / f"duplicate-finder-gtk_{VERSION}_all.deb"
        env = dict(os.environ, SOURCE_DATE_EPOCH=str(EPOCH))
        subprocess.run(["dpkg-deb", "--root-owner-group", "-Zxz", "--build", str(stage), str(target)], check=True, env=env)
        print(target)


if __name__ == "__main__":
    build()
